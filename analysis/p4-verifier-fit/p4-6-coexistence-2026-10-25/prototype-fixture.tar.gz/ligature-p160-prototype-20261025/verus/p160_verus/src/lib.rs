//! Synthetic verifier coexistence probe. This is not a production P3 guarantee.

use vstd::prelude::*;

verus! {
    pub fn increment(x: u32) -> (result: u32)
        requires x < u32::MAX,
        ensures result == x + 1,
    {
        x + 1
    }
}
