#!/usr/bin/env python3
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

record_path = Path(sys.argv[1])
record = json.loads(record_path.read_text())
root = record_path.parent.parent
logs = root / "logs"
logs.mkdir(parents=True, exist_ok=True)
label = record["label"]
stdout_path = logs / f"{label}.stdout.txt"
stderr_path = logs / f"{label}.stderr.txt"
env = os.environ.copy()
for key, value in record.get("environment_overrides", {}).items():
    env[key] = value
record["started_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
try:
    completed = subprocess.run(
        record["argv"], cwd=record["cwd"], env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False,
    )
    record["exit_code"] = completed.returncode
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
except Exception as exc:
    record["exit_code"] = 127
    record["runner_error"] = repr(exc)
    stdout_path.write_text("")
    stderr_path.write_text(repr(exc) + "\n")
record["elapsed_seconds"] = round(time.monotonic() - start, 3)
record["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record["stdout_file"] = str(stdout_path)
record["stderr_file"] = str(stderr_path)
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"label": label, "exit_code": record["exit_code"], "elapsed_seconds": record["elapsed_seconds"], "stdout_file": str(stdout_path), "stderr_file": str(stderr_path)}))
sys.exit(record["exit_code"])
