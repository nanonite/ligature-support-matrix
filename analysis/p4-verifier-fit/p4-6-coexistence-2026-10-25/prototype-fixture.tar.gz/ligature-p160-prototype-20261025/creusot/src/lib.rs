//! Synthetic verifier coexistence probe. This is not a production P3 guarantee.

#[cfg(not(kani))]
use creusot_std::prelude::*;

#[cfg_attr(not(kani), requires(x@ < u32::MAX@))]
#[cfg_attr(not(kani), ensures(result@ == x@ + 1))]
pub fn increment(x: u32) -> u32 {
    x + 1
}

#[cfg(kani)]
#[kani::proof]
fn increment_matches_postcondition_for_all_nonmax_inputs() {
    let x: u32 = kani::any();
    kani::assume(x < u32::MAX);
    assert!(increment(x) == x + 1);
}
