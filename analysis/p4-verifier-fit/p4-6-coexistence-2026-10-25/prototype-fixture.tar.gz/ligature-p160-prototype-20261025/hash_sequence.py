#!/usr/bin/env python3
import hashlib
import json
import re
import sys
from pathlib import Path

base = Path('/tmp/ligature-p160-prototype-20261025')
paths = [
    'creusot/Cargo.toml', 'creusot/Cargo.lock', 'creusot/rust-toolchain.toml',
    'creusot/.cargo/config.toml', 'creusot/why3find.json', 'creusot/src/lib.rs',
    'creusot/verif/p160_creusot_kani_rlib/increment.coma',
    'creusot/verif/p160_creusot_kani_rlib/increment/proof.json',
    'outputs/creusot-external-proof/verif/p160_creusot_kani_rlib/increment.coma',
    'verus/p160_verus/Cargo.toml', 'verus/p160_verus/Cargo.lock',
    'verus/p160_verus/rust-toolchain.toml', 'verus/p160_verus/src/lib.rs',
    'outputs/verus/proof-results.json',
    'logs/creusot-proof-first.stdout.txt', 'logs/creusot-proof-first.stderr.txt',
    'logs/creusot-external-output-proof.stdout.txt', 'logs/creusot-external-output-proof.stderr.txt',
    'logs/verus-build-first.stdout.txt', 'logs/verus-build-first.stderr.txt',
    'logs/kani-proof.stdout.txt', 'logs/kani-proof.stderr.txt',
    'commands/creusot-proof-first.command.json',
    'commands/creusot-external-output-proof.command.json',
    'commands/verus-build-first.command.json',
    'commands/kani-proof.command.json',
]
kani_log = (base / 'logs/kani-proof.stdout.txt').read_text()
match = re.search(r'Reading GOTO program from file (\S+)', kani_log)
if match:
    gotopath = Path(match.group(1))
    try:
        paths.append(str(gotopath.relative_to(base)))
    except ValueError:
        pass
for rel in sorted(set(paths)):
    p = base / rel
    if not p.is_file():
        raise SystemExit(f'missing expected sequence input/output: {rel}')
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    print(f'{digest}  {rel}')
out = Path(sys.argv[1])
out.write_text('\n'.join(f'{hashlib.sha256((base / rel).read_bytes()).hexdigest()}  {rel}' for rel in sorted(set(paths))) + '\n')
